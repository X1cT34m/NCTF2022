build-once run-anywhere

run on windows

./chall.com

run on Linux 

bash -c "./chall.com"

run on macos

bash -c "./chall.com"
