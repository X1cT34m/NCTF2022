-- MySQL dump 10.13  Distrib 5.7.40, for Linux (x86_64)
--
-- Host: localhost    Database: aya3
-- ------------------------------------------------------
-- Server version	5.7.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `aya3`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `aya3` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `aya3`;

--
-- Table structure for table `aya3_book`
--

DROP TABLE IF EXISTS `aya3_book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aya3_book` (
  `itemid` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `posttime` int(10) NOT NULL DEFAULT '0',
  `name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `tel` varchar(20) NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `posttime` (`posttime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aya3_book`
--

LOCK TABLES `aya3_book` WRITE;
/*!40000 ALTER TABLE `aya3_book` DISABLE KEYS */;
/*!40000 ALTER TABLE `aya3_book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aya3_channel`
--

DROP TABLE IF EXISTS `aya3_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aya3_channel` (
  `channelid` smallint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(20) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `language` varchar(10) NOT NULL DEFAULT '',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  `isblank` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dirname` varchar(20) NOT NULL DEFAULT '',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `hide_pc` tinyint(1) NOT NULL DEFAULT '0',
  `hide_tc` tinyint(1) NOT NULL DEFAULT '0',
  `hide_wx` tinyint(1) NOT NULL DEFAULT '0',
  `parentid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `pagesize` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `table` varchar(50) NOT NULL DEFAULT '',
  `orderby` varchar(250) NOT NULL DEFAULT '',
  `pv` text NOT NULL,
  `config` varchar(255) NOT NULL DEFAULT '',
  `comment` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`channelid`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aya3_channel`
--

LOCK TABLES `aya3_channel` WRITE;
/*!40000 ALTER TABLE `aya3_channel` DISABLE KEYS */;
INSERT INTO `aya3_channel` VALUES (4,'home','首页','dem_home/','zh-cn',4,0,'dem_home','','',0,0,0,0,0,'','','','',0),(6,'epage','关于','dem_guanyu/','zh-cn',0,0,'dem_guanyu','','',0,0,0,0,0,'epage','','','',0);
/*!40000 ALTER TABLE `aya3_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aya3_class`
--

DROP TABLE IF EXISTS `aya3_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aya3_class` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(6) NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  `channelid` smallint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aya3_class`
--

LOCK TABLES `aya3_class` WRITE;
/*!40000 ALTER TABLE `aya3_class` DISABLE KEYS */;
/*!40000 ALTER TABLE `aya3_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aya3_comment`
--

DROP TABLE IF EXISTS `aya3_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aya3_comment` (
  `itemid` int(10) NOT NULL AUTO_INCREMENT,
  `author` varchar(20) NOT NULL DEFAULT '0',
  `posttime` int(10) NOT NULL DEFAULT '0',
  `content` longtext NOT NULL,
  `channelid` mediumint(8) NOT NULL DEFAULT '0',
  `itemid_by` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `posttime` (`posttime`),
  KEY `itemid_by` (`itemid_by`),
  KEY `channelid` (`channelid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aya3_comment`
--

LOCK TABLES `aya3_comment` WRITE;
/*!40000 ALTER TABLE `aya3_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `aya3_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aya3_epage`
--

DROP TABLE IF EXISTS `aya3_epage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aya3_epage` (
  `itemid` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `channelid` mediumint(8) NOT NULL,
  PRIMARY KEY (`itemid`),
  UNIQUE KEY `channelid` (`channelid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aya3_epage`
--

LOCK TABLES `aya3_epage` WRITE;
/*!40000 ALTER TABLE `aya3_epage` DISABLE KEYS */;
INSERT INTO `aya3_epage` VALUES (1,'关于','<img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAfQAAAH0CAIAAABEtEjdAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAJ3klEQVR4nO3dsW7kRhRFwRlD///LcuJgV4nVsJ/29WFVvCAoknPQ0d335+fnC4CWv/70DQDw/xN3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4AgcQcI+pi79Pv9nrt43ufn5/f/8dGjPrrykdM3Pvc3LrmNuUd9au62/cz/i9EvxMkdIEjcAYLEHSBI3AGCxB0gSNwBgsQdIEjcAYLEHSBI3AGCxB0gSNwBgsQdIEjcAYIGJ3+P7BlHnXPjaO2oJfO5lz6QG/mZ/yQnd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4AgcQcI2jL5e2TPqGZ+wnTPmPCSfeA99ryaIXvu+dLPyckdIEjcAYLEHSBI3AGCxB0gSNwBgsQdIEjcAYLEHSBI3AGCxB0gSNwBgsQdIEjcAYKunPzli7lx1D1Du3N/46WDrnteDTs5uQMEiTtAkLgDBIk7QJC4AwSJO0CQuAMEiTtAkLgDBIk7QJC4AwSJO0CQuAMEiTtAkMnfgqNB1yX7wK8H7NDOPWr4V07uAEHiDhAk7gBB4g4QJO4AQeIOECTuAEHiDhAk7gBB4g4QJO4AQeIOECTuAEHiDhAk7gBBV+6553fALzX6XuY265dc+fTic1de8vtachv3cnIHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gKAtk79zY6dPsGTh9tSNO7R77HmP37fkNh7CyR0gSNwBgsQdIEjcAYLEHSBI3AGCxB0gSNwBgsQdIEjcAYLEHSBI3AGCxB0gSNwBgt6WVJ9mz+zq3GjtkjncPT8u68oP5OQOECTuAEHiDhAk7gBB4g4QJO4AQeIOECTuAEHiDhAk7gBB4g4QJO4AQeIOECTuAEFXTv7euP56askc7pHRp7fkPe75vSz5Vi99IEt+BaNPz8kdIEjcAYLEHSBI3AGCxB0gSNwBgsQdIEjcAYLEHSBI3AGCxB0gSNwBgsQdIEjcAYI+5i69Z/pyzo3Dod7LF3PbuadXvvRpD9nz9JasK59ycgcIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAoLeV0V+NroxeOhz6faPf0pKl4vxLHHXpFzL30kcfiJM7QJC4AwSJO0CQuAMEiTtAkLgDBIk7QJC4AwSJO0CQuAMEiTtAkLgDBIk7QJC4AwR9/Okb+MeSJdXTBc4bV0bnjA4m55/ey1Lx70Y/pydwcgcIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCNqy5/4Ec+PvfPGEp5f/vwT2/OcKl3JyBwgSd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4Cg/uTvnrHTG1dGR2dUbxytHX2Jc7e9ZMV31JIvZA8nd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4AgcQcI6k/+jppbGV1y5dGF2/wG8qn8AxldkOYLJ3eAIHEHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCHrfuKs5Ors6Z8mK79zTG/2Wlrz0JY961Nx7NJj8k5zcAYLEHSBI3AGCxB0gSNwBgsQdIEjcAYLEHSBI3AGCxB0gSNwBgsQdIEjcAYLEHSDoY+7SS/ZORzdabxyAvXQZ9dId2jlL3uOlT2/O3Fj3KSd3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gCBxBwh6Gw791ZKn8brzgewZTL5xinnUkg97zxzukpdu8heAM+IOECTuAEHiDhAk7gBB4g4QJO4AQeIOECTuAEHiDhAk7gBB4g4QJO4AQeIOECTuAEEfc5e+cYB7zyL5nLkJ6SWj4Xs84YHs+THyhZM7QJC4AwSJO0CQuAMEiTtAkLgDBIk7QJC4AwSJO0CQuAMEiTtAkLgDBIk7QJC4AwS9l6ySzu0Dz93Gqbl94CUP5PQ2btx0XfJ7ea35Qo7s+Zwu/ckccXIHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gKDByd+56cu5qdhLR2uXvMRTS257yW2cWvKT2WPJA1myrvxycgdIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAoMHJX37MpYOu+Y3WJ7yXOU8YTB591E7uAEHiDhAk7gBB4g4QJO4AQeIOECTuAEHiDhAk7gBB4g4QJO4AQeIOECTuAEHiDhD0MXfpS/dOlzjaAr10tHbJkurRbSyZw93j0qf3hDo5uQMEiTtAkLgDBIk7QJC4AwSJO0CQuAMEiTtAkLgDBIk7QJC4AwSJO0CQuAMEiTtA0ODk75E9W6Bz5lZG52ZX97yXJfvAo26cbvb0fuw2Tjm5AwSJO0CQuAMEiTtAkLgDBIk7QJC4AwSJO0CQuAMEiTtAkLgDBIk7QJC4AwSJO0DQlsnfI3P7paf2zHt+35711z3vcciNn8frAe/lIZzcAYLEHSBI3AGCxB0gSNwBgsQdIEjcAYLEHSBI3AGCxB0gSNwBgsQdIEjcAYLEHSBI3AGCrtxz54tLd8OPzP2NR/Plo496yZ0s+ZxGZ+WfsFnv5A4QJO4AQeIOECTuAEHiDhAk7gBB4g4QJO4AQeIOECTuAEHiDhAk7gBB4g4QJO4AQSZ/C56wXzpnyZjwqCes+B5Z8tJH34uTO0CQuAMEiTtAkLgDBIk7QJC4AwSJO0CQuAMEiTtAkLgDBIk7QJC4AwSJO0CQuAMEXTn5u2S/dI+jBzI3SXo66Lrktuec3sbR37jkgez5nI7MXXzJt/dycgdIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAIHEHCBJ3gCBxBwgSd4AgcQcIEneAoPeSLVC+2DMcOic/WjvqxtsebcKePeHvG30vTu4AQeIOECTuAEHiDhAk7gBB4g4QJO4AQeIOECTuAEHiDhAk7gBB4g4QJO4AQeIOEDQ4+QvAn+LkDhAk7gBB4g4QJO4AQeIOECTuAEHiDhAk7gBB4g4QJO4AQeIOECTuAEHiDhAk7gBB4g4QJO4AQeIOECTuAEHiDhAk7gBB4g4QJO4AQeIOECTuAEHiDhAk7gBB4g4QJO4AQeIOECTuAEF/A6aNFwbuTlBOAAAAAElFTkSuQmCC\">',6);
/*!40000 ALTER TABLE `aya3_epage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aya3_field`
--

DROP TABLE IF EXISTS `aya3_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aya3_field` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tb` varchar(30) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(100) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT '',
  `html` varchar(30) NOT NULL DEFAULT '',
  `default_value` text NOT NULL,
  `option_value` text NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `input_limit` tinyint(1) NOT NULL DEFAULT '0',
  `addition` varchar(255) NOT NULL DEFAULT '',
  `display` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `front` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  `vmin` int(10) unsigned NOT NULL DEFAULT '0',
  `vmax` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aya3_field`
--

LOCK TABLES `aya3_field` WRITE;
/*!40000 ALTER TABLE `aya3_field` DISABLE KEYS */;
INSERT INTO `aya3_field` VALUES (2,'article_1','ttaea','妈呀','','','thumb','','',0,0,0,'',1,0,1,0,100),(3,'product_2','ykuok','来源','','','text','','',0,0,0,'',1,1,0,0,100);
/*!40000 ALTER TABLE `aya3_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aya3_link`
--

DROP TABLE IF EXISTS `aya3_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aya3_link` (
  `itemid` int(10) NOT NULL AUTO_INCREMENT,
  `titles` text NOT NULL,
  `contents` text NOT NULL,
  `posttime` int(10) NOT NULL DEFAULT '0',
  `openlinks` text NOT NULL,
  `urls` text NOT NULL,
  `note` varchar(255) NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `posttime` (`posttime`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aya3_link`
--

LOCK TABLES `aya3_link` WRITE;
/*!40000 ALTER TABLE `aya3_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `aya3_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aya3_member`
--

DROP TABLE IF EXISTS `aya3_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aya3_member` (
  `itemid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `password` varchar(64) NOT NULL,
  `regtime` int(10) NOT NULL DEFAULT '0',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `groupid` tinyint(2) NOT NULL DEFAULT '1',
  `email` varchar(255) NOT NULL,
  `post_sum` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `last_post` int(10) NOT NULL DEFAULT '0',
  `aya_a` int(10) NOT NULL DEFAULT '0',
  `aya_b` int(10) NOT NULL DEFAULT '0',
  `aya_c` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aya3_member`
--

LOCK TABLES `aya3_member` WRITE;
/*!40000 ALTER TABLE `aya3_member` DISABLE KEYS */;
INSERT INTO `aya3_member` VALUES (1,'admin','b94174525ccb25ac2fc619b5e8aadf3b',1669895765,0,2,'',0,0,2700,135,27);
/*!40000 ALTER TABLE `aya3_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aya3_pic`
--

DROP TABLE IF EXISTS `aya3_pic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aya3_pic` (
  `itemid` int(10) NOT NULL AUTO_INCREMENT,
  `titles` text NOT NULL,
  `contents` text NOT NULL,
  `posttime` int(10) NOT NULL DEFAULT '0',
  `openlinks` text NOT NULL,
  `urls` text NOT NULL,
  `note` varchar(255) NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `posttime` (`posttime`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aya3_pic`
--

LOCK TABLES `aya3_pic` WRITE;
/*!40000 ALTER TABLE `aya3_pic` DISABLE KEYS */;
INSERT INTO `aya3_pic` VALUES (2,'我的网站|||||||||','|||||||||',1437369519,'/|||||||||','1507/20/14373719197252.png|||||||||','网站LOGO');
/*!40000 ALTER TABLE `aya3_pic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aya3_poll`
--

DROP TABLE IF EXISTS `aya3_poll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aya3_poll` (
  `itemid` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `posttime` int(10) NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL,
  `polls` varchar(255) NOT NULL,
  `items` text NOT NULL,
  `content` text NOT NULL,
  `ty` tinyint(2) NOT NULL DEFAULT '0',
  `jy` varchar(50) NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `posttime` (`posttime`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aya3_poll`
--

LOCK TABLES `aya3_poll` WRITE;
/*!40000 ALTER TABLE `aya3_poll` DISABLE KEYS */;
INSERT INTO `aya3_poll` VALUES (1,'网站调查',1437363655,'首页用 喜欢AyaCMS吗?','3|0|0|1|0|0|0|0|0|0','喜欢|一般喜欢|很喜欢|喜欢极了|喜欢死了|||||','你喜欢AyaCMS吗?',1,'1437381000Mozilla/5.0 (Windows NT 6.1; WOW64) Appl');
/*!40000 ALTER TABLE `aya3_poll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aya3_search`
--

DROP TABLE IF EXISTS `aya3_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aya3_search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channelid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `itemid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `posttime` int(10) NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL,
  `sign` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post_time` (`posttime`),
  KEY `pid` (`itemid`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aya3_search`
--

LOCK TABLES `aya3_search` WRITE;
/*!40000 ALTER TABLE `aya3_search` DISABLE KEYS */;
INSERT INTO `aya3_search` VALUES (2,1,2,1436419929,'我爱中华','');
/*!40000 ALTER TABLE `aya3_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aya3_tag`
--

DROP TABLE IF EXISTS `aya3_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aya3_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag` varchar(20) NOT NULL,
  `channelid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `itemid` mediumint(8) NOT NULL DEFAULT '0',
  `sign` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `posttime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tag` (`tag`),
  KEY `post_time` (`posttime`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aya3_tag`
--

LOCK TABLES `aya3_tag` WRITE;
/*!40000 ALTER TABLE `aya3_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `aya3_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aya3_text`
--

DROP TABLE IF EXISTS `aya3_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aya3_text` (
  `itemid` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `posttime` int(10) NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `posttime` (`posttime`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aya3_text`
--

LOCK TABLES `aya3_text` WRITE;
/*!40000 ALTER TABLE `aya3_text` DISABLE KEYS */;
/*!40000 ALTER TABLE `aya3_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aya3_video`
--

DROP TABLE IF EXISTS `aya3_video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aya3_video` (
  `itemid` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `posttime` int(10) NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `posttime` (`posttime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aya3_video`
--

LOCK TABLES `aya3_video` WRITE;
/*!40000 ALTER TABLE `aya3_video` DISABLE KEYS */;
/*!40000 ALTER TABLE `aya3_video` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-01 12:08:36
