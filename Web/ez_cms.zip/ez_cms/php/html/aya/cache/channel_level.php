<?php defined('IN_AYA') or exit('Access Denied'); return array (
  'zh-cn' => 
  array (
    0 => 
    array (
      0 => 4,
      1 => 6,
    ),
  ),
); ?>