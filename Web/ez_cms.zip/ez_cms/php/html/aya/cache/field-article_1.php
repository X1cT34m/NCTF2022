<?php defined('IN_AYA') or exit('Access Denied'); return array (
  'ttaea' => 
  array (
    'itemid' => '2',
    'tb' => 'article_1',
    'name' => 'ttaea',
    'title' => '妈呀',
    'note' => '',
    'type' => '',
    'html' => 'thumb',
    'default_value' => '',
    'option_value' => '',
    'width' => '0',
    'height' => '0',
    'input_limit' => '0',
    'addition' => '',
    'display' => '1',
    'front' => '0',
    'listorder' => '1',
    'vmin' => '0',
    'vmax' => '100',
  ),
); ?>