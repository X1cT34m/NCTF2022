<?php defined('IN_AYA') or exit('Access Denied'); return array (
  'ykuok' => 
  array (
    'itemid' => '3',
    'tb' => 'product_2',
    'name' => 'ykuok',
    'title' => '来源',
    'note' => '',
    'type' => '',
    'html' => 'text',
    'default_value' => '',
    'option_value' => '',
    'width' => '0',
    'height' => '0',
    'input_limit' => '0',
    'addition' => '',
    'display' => '1',
    'front' => '1',
    'listorder' => '0',
    'vmin' => '0',
    'vmax' => '100',
  ),
); ?>