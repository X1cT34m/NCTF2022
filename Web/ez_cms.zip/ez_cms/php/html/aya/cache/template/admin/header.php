<?php defined('IN_AYA') or exit('Access Denied');?><!DOCTYPE HTML>
<html lang="<?php echo AYA_LANG;?>">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title><?php include tag('title');?></title>
<meta name="Description" content="<?php include tag('description');?>">
<meta name="Keywords" content="<?php include tag('keywords');?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="<?php echo AYA_TURL;?>aya/css/zui.min.css" rel="stylesheet">
<link href="<?php echo AYA_TURL;?>aya/lib/datetimepicker/datetimepicker.css" rel="stylesheet">
<link href="<?php echo AYA_URL;?>aya/include/uploadifive/uploadifive.css" rel="stylesheet">
<link href="<?php echo AYA_TURL;?>aya/index.css" rel="stylesheet">
    <script src="<?php echo AYA_TURL;?>aya/js/jquery-1.11.0.min.js"></script>
    <script src="<?php echo AYA_TURL;?>aya/js/jquery.cookie.js"></script>
    <script src="<?php echo AYA_TURL;?>aya/js/zui.min.js"></script>
    <!--[if lt IE 9]>
  <script src="<?php echo AYA_TURL;?>aya/js/html5shiv.js"></script>
  <script src="<?php echo AYA_TURL;?>aya/js/respond.min.js"></script>
<![endif]-->
  <script src="<?php echo AYA_TURL;?>aya/lib/datetimepicker/datetimepicker.min.js"></script>
  <script src="<?php echo AYA_TURL;?>aya/lib/chosen/chosen.min.js"></script>
  <script src="<?php echo AYA_TURL;?>aya/lib/chosen/chosen.icons.min.js" type="text/javascript"></script>
  <script src="<?php echo AYA_URL;?>aya/include/uploadifive/jquery.uploadifive.min.js" type="text/javascript"></script>
   <script type="text/javascript">
  var AYA_ADMIN_URL="<?php echo AYA_ADMIN_URL;?>";
    
 $(function(){
 open_msg();
 
 });
</script>
<script src="<?php echo AYA_TURL;?>aya/jquery.scrollUp.min.js"></script> 
<script src="<?php echo AYA_TURL;?>aya/index.js"></script>
</head>
<body>
<!--[if lt IE 8]>
        <div class="alert alert-danger">您正在使用 <strong>过时的</strong> 浏览器. 是时候 <a href="http://browsehappy.com/">更换一个更好的浏览器</a> 来提升用户体验.</div>
<![endif]-->
<div class="container-fluid">
<div class="row">
 <div class="col-md-12"> 
 <div style="padding:10px 0px">
  <div class="pull-left"><?php include tag('mainmenu');?></div>
  <div class="pull-right"><?php include tag('lang');?></div>
  <div class="pull-right"> &nbsp;&nbsp;&nbsp;&nbsp;</div>
  <div class="pull-right"><?php include tag('usernav');?></div>
  <div class="clearfix"></div>
  </div>
  </div>
</div>
<div class="header <?php if($_COOKIE['fix_navbar']) { ?>in<?php } else { ?>collapse<?php } ?>
" id="channelmenu">
<?php include tag('navbar');?>
</div>
<div id="container">
