<?php defined('IN_AYA') or exit('Access Denied');?>
<div class="clearfix"></div>
</div>
</div>
<div class="clearfix"></div>
<div class="footer">
 Powered by <a href="http://www.ayacms.com" target="_blank">AyaCMS</a> <?php echo timer_end();?>
</div>
</body>
</html>