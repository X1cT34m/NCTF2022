<?php defined('IN_AYA') or exit('Access Denied');?><?php include template('header');?>
<?php include tag('pathnav');?>
<div class="article-content" style="padding:0 20px 0">
<h3><?php echo html($item['title']);?></h3>
<?php echo $item['content'];?>
</div>
<?php echo fields_show();?>