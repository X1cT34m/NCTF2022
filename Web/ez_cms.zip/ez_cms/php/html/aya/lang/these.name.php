<?php
return array (
		'zh-cn.inc.php'=>'简',
		'zh-tw.inc.php'=>'繁', 
		'en.inc.php'=>'En' 
);