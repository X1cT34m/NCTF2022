<?php
foreach ($values as $val)
echo html($val).' ';