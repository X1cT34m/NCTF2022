<?php

echo html($value);