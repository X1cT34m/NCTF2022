<?php
return array (
		'admin'=>'后台管理',
		'anull'=>'空页',
		'article'=>'文章',
		'product'=>'产品',
		'picture'=>'图片',
		'video'=>'视频',
		'atag'=>'标签',
		'book'=>'留言本',
		'home'=>'首页',
		'member'=>'会员中心',
		'apage'=>'独立页',
		'epage'=>'通用独立页',
		'search'=>'搜索',
		'sitemap'=>'网站地图',
);