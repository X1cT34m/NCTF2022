<?php
defined('IN_AYA') or exit('Access Denied');

$p['path']='';
return true;
