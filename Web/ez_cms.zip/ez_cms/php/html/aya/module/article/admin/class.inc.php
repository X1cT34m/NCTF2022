<?php
defined('IN_AYA') or exit('Access Denied');

$items=$CS;

htmls($items);
include template($action,'article');
