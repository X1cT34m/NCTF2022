<?php
defined('IN_AYA') or exit('Access Denied');

$p['table']='member';
return true;
