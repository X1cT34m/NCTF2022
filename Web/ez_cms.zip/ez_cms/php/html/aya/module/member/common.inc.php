<?php
defined('IN_AYA') or exit('Access Denied');
$FD = cache_read('field-'.$c_table.'.php');
