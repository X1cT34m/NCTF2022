<?php
defined('IN_AYA') or exit('Access Denied');

upcache();
amsg(l('更新成功'),'s');