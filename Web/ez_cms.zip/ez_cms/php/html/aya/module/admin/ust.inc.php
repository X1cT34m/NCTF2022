<?php
defined('IN_AYA') or exit('Access Denied');


include template($action,'admin');