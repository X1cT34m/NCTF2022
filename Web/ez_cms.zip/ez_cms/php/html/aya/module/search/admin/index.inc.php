<?php
defined('IN_AYA') or exit('Access Denied');

header('Location: ?action=tpl&channelid='.$channelid.'&in_module=1');
