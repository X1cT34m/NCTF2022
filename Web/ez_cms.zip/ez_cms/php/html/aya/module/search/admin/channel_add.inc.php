<?php
defined('IN_AYA') or exit('Access Denied');

$p['table']='search';
$p['pagesize']=20;
return true;
