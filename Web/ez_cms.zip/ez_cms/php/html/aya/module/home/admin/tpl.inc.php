<?php
defined('IN_AYA') or exit('Access Denied');

include AYA_ROOT.'module/article/admin/'.$action.'.inc.php';