<?php
defined('IN_AYA') or exit('Access Denied');

$p['table']='tag';
$p['pagesize']=20;
return true;
