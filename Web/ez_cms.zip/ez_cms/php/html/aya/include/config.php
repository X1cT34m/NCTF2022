<?php defined('IN_AYA') or exit('Access Denied');
			return array (
  'rewrite' => 0,
  'database' => 'mysql',
  'pconnect' => '0',
  'db_host' => 'localhost',
  'db_name' => 'aya3',
  'db_user' => 'root',
  'db_pass' => '',
  'db_charset' => 'utf8',
  'db_pre' => 'aya3_',
  'smtp_host' => 'smtp.qq.com',
  'smtp_port' => '465',
  'smtp_username' => '1106088788@qq.com',
  'smtp_password' => '',
  'smtp_from' => '1106088788@qq.com',
  'url' => 'http://localhost/',
  'title' => '我的网站',
  'keywords' => '我的网站关键字',
  'description' => '我的网站说明',
  'email' => '',
  'template_pc' => 'default',
  'template_tc' => 'default',
  'template_wx' => 'default',
  'lang' => 'zh-cn',
  'timezone' => 'Etc/GMT-8',
  'cookie_pre' => 'aya_',
  'aya_key' => 'aaa',
  'kregword' => 'admin,管理,版主,moderator',
  'add_a' => 100,
  'add_b' => 5,
  'add_c' => 1,
  'reggroup' => '1',
  'groups' => 'group_0,group_1,group_2,group_3,group_4',
  'aanew' => 3600,
  'aahot' => 10,
  'aayouhao' => 0,
  'aacolor' => 
  array (
    'red' => '红色
',
    'green' => '绿色
',
    'blue' => '蓝色
',
    '#f30' => '橙色',
  ),
);
					