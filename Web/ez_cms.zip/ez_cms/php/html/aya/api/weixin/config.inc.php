<?php defined('IN_AYA') or exit('Access Denied');
			return array (
  'appid' => '',
  'appsecret' => '',
  'url' => '',
  'token' => '',
  'menu' => 
  array (
    0 => 
    array (
      1 => 
      array (
        'name' => '',
        'type' => 'click',
        'text' => '',
        'link' => '',
        'url' => '',
      ),
      2 => 
      array (
        'name' => '',
        'type' => 'click',
        'text' => '',
        'link' => 'http://www.baidu.com',
        'url' => '',
      ),
      0 => 
      array (
        'name' => '',
        'type' => '',
        'text' => '',
        'link' => '',
        'url' => '碰',
      ),
      3 => 
      array (
        'name' => '',
        'type' => 'click',
        'text' => '',
        'link' => '',
        'url' => '',
      ),
      4 => 
      array (
        'name' => '',
        'type' => 'click',
        'text' => '',
        'link' => '',
        'url' => '',
      ),
      5 => 
      array (
        'name' => '',
        'type' => 'click',
        'text' => '',
        'link' => '',
        'url' => '',
      ),
    ),
    1 => 
    array (
      0 => 
      array (
        'name' => '',
        'type' => '',
        'text' => 'dsfsdfsdf',
        'link' => '',
        'url' => '',
      ),
      5 => 
      array (
        'name' => '',
        'type' => 'view',
        'text' => '',
        'link' => '',
        'url' => 'http://www.baidu.com',
      ),
      2 => 
      array (
        'name' => '',
        'type' => 'click',
        'text' => '',
        'link' => '',
        'url' => '',
      ),
      1 => 
      array (
        'name' => '',
        'type' => 'click',
        'text' => '',
        'link' => '',
        'url' => '',
      ),
    ),
    2 => 
    array (
      2 => 
      array (
        'name' => '',
        'type' => 'click',
        'text' => '',
        'link' => '',
        'url' => '',
      ),
      0 => 
      array (
        'name' => '',
        'type' => '',
        'text' => '',
        'link' => '',
        'url' => '',
      ),
    ),
  ),
);
					