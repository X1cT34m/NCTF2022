<?php
define('AYA_VERSION', '3.1.2');
define('AYA_RELEASE', '20151108');