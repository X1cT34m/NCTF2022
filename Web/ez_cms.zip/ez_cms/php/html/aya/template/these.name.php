<?php
 return array (
  'default' => '缺省风格'
);