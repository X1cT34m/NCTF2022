<?php defined('IN_AYA') or exit('Access Denied');
			return array (
  'index.html' => '首页',
);
					