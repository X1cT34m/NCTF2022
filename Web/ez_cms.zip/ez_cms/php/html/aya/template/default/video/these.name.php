<?php defined('IN_AYA') or exit('Access Denied');
			return array (
  'index.html' => '',
  'show.html' => '内容页',
);
					