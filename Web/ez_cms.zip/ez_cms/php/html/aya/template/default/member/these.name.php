<?php defined('IN_AYA') or exit('Access Denied');
			return array (
  'edit.html' => '',
  'index.html' => '',
  'login.html' => '',
  'pass.html' => '',
  'passz.html' => '',
  'reg.html' => '',
  'show.html' => ''
);
					