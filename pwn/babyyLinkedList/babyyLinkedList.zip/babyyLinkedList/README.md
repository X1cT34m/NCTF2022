# NCTF2022 - babyyLinkedList

babyy challenge in kernel space, just sign me in please

Here are some kernel config options that you may need

```
CONFIG_SLUB=y
CONFIG_SLAB_FREELIST_RANDOM=y
CONFIG_SLAB_FREELIST_HARDENED=y
CONFIG_HARDENED_USERCOPY=y
```

