# NCTF2022 - ezlogin

a challenge statically compiled by g++ in ubuntu 20.04